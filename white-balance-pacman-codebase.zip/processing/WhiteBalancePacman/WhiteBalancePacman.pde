import processing.serial.*;

// ---------- Window and game ----------
final int WINDOW_W = 1000;
final int WINDOW_H = 700;
final float PLAYER_RADIUS = 22;
final float PLAYER_SPEED = 3.4;
final float LIGHT_RANGE = 230;
final float LIGHT_HALF_ANGLE = radians(32);

float pacmanX;
float pacmanY;
float facingAngle = 0;
boolean moveLeft, moveRight, moveUp, moveDown;

int currentR = 255;
int currentG = 255;
int currentB = 255;
int lastSentR = -1;
int lastSentG = -1;
int lastSentB = -1;
int lastColorSendTime = 0;
final int COLOR_SEND_INTERVAL_MS = 40;
int score = 0;

PImage towerImage;
Serial arduino;
String connectionMessage = "Arduino not connected";

ArrayList<Coin> coins = new ArrayList<Coin>();

void settings() {
  size(WINDOW_W, WINDOW_H);
}

void setup() {
  smooth(8);
  frameRate(60);

  // Spawn point: the tower at the center of the map.
  pacmanX = width * 0.5;
  pacmanY = height * 0.67;

  towerImage = loadImage("tower-front-view.png");
  if (towerImage != null) makeBlackPixelsTransparent(towerImage);

  createCoins();
  connectToArduino();
}

void draw() {
  updatePlayer();
  updateWhiteBalance();
  updateCoins();
  sendColorIfChanged();

  drawWhiteDarknessAndCoordinates();
  drawFlashlight();
  drawTower();
  drawCoins();
  drawPacman();
  drawInterface();
}

void updatePlayer() {
  float dx = 0;
  float dy = 0;

  if (moveLeft) dx--;
  if (moveRight) dx++;
  if (moveUp) dy--;
  if (moveDown) dy++;

  if (dx != 0 || dy != 0) {
    float length = sqrt(dx * dx + dy * dy);
    dx /= length;
    dy /= length;
    pacmanX += dx * PLAYER_SPEED;
    pacmanY += dy * PLAYER_SPEED;
    facingAngle = atan2(dy, dx);
  }

  pacmanX = constrain(pacmanX, PLAYER_RADIUS, width - PLAYER_RADIUS);
  pacmanY = constrain(pacmanY, PLAYER_RADIUS + 50, height - PLAYER_RADIUS);
}

void updateWhiteBalance() {
  float temperature = map(pacmanX, 0, width, -1, 1);
  float tint = map(pacmanY, 50, height, -1, 1);

  float red = 255;
  float green = 255;
  float blue = 255;

  if (temperature > 0) {
    blue -= temperature * 180;
  } else {
    red -= -temperature * 180;
  }

  if (tint > 0) {
    red -= tint * 100;
    blue -= tint * 100;
  } else {
    green -= -tint * 140;
  }

  currentR = constrain(round(red), 0, 255);
  currentG = constrain(round(green), 0, 255);
  currentB = constrain(round(blue), 0, 255);
}

void drawWhiteDarknessAndCoordinates() {
  background(255);

  // The white field represents darkness. Coordinates remain faintly visible.
  stroke(225);
  strokeWeight(1);
  for (int x = 0; x <= width; x += 50) line(x, 50, x, height);
  for (int y = 50; y <= height; y += 50) line(0, y, width, y);

  stroke(185);
  strokeWeight(2);
  line(width / 2, 50, width / 2, height);
  line(0, height / 2, width, height / 2);

  fill(120);
  textSize(13);
  textAlign(LEFT, CENTER);
  text("COOL / BLUE", 16, height / 2 - 14);
  textAlign(RIGHT, CENTER);
  text("WARM / YELLOW", width - 16, height / 2 - 14);
  textAlign(CENTER, TOP);
  text("MAGENTA TINT", width / 2, 58);
  textAlign(CENTER, BOTTOM);
  text("GREEN TINT", width / 2, height - 10);
}

void drawFlashlight() {
  pushMatrix();
  translate(pacmanX, pacmanY);
  rotate(facingAngle);
  noStroke();

  // A soft outer cone and a more visible inner cone.
  fill(currentR, currentG, currentB, 35);
  arc(0, 0, LIGHT_RANGE * 2.2, LIGHT_RANGE * 2.2,
      -LIGHT_HALF_ANGLE * 1.18, LIGHT_HALF_ANGLE * 1.18, PIE);
  fill(currentR, currentG, currentB, 105);
  arc(0, 0, LIGHT_RANGE * 2, LIGHT_RANGE * 2,
      -LIGHT_HALF_ANGLE, LIGHT_HALF_ANGLE, PIE);
  popMatrix();
}

void drawPacman() {
  pushMatrix();
  translate(pacmanX, pacmanY);
  rotate(facingAngle);

  noStroke();
  fill(currentR, currentG, currentB);
  float mouth = radians(28);
  arc(0, 0, PLAYER_RADIUS * 2, PLAYER_RADIUS * 2,
      mouth, TWO_PI - mouth, PIE);

  fill(20);
  circle(3, -10, 5);
  popMatrix();
}

void createCoins() {
  coins.add(new Coin(150, 150));
  coins.add(new Coin(330, 250));
  coins.add(new Coin(760, 160));
  coins.add(new Coin(850, 430));
  coins.add(new Coin(650, 560));
  coins.add(new Coin(230, 540));
  coins.add(new Coin(520, 180));
  coins.add(new Coin(470, 460));
}

void updateCoins() {
  for (Coin coin : coins) {
    if (coin.collected) continue;

    if (isInsideFlashlight(coin.x, coin.y)) coin.discovered = true;

    if (dist(pacmanX, pacmanY, coin.x, coin.y) < PLAYER_RADIUS + coin.radius) {
      coin.collected = true;
      score++;
      sendBlink();
    }
  }
}

boolean isInsideFlashlight(float targetX, float targetY) {
  float dx = targetX - pacmanX;
  float dy = targetY - pacmanY;
  float distance = sqrt(dx * dx + dy * dy);
  if (distance > LIGHT_RANGE) return false;

  float targetAngle = atan2(dy, dx);
  float difference = atan2(sin(targetAngle - facingAngle),
                           cos(targetAngle - facingAngle));
  return abs(difference) <= LIGHT_HALF_ANGLE;
}

void drawCoins() {
  for (Coin coin : coins) {
    if (coin.collected) continue;
    boolean illuminated = isInsideFlashlight(coin.x, coin.y);
    if (!coin.discovered && !illuminated) continue;

    noStroke();
    fill(255, 185, 25, illuminated ? 255 : 115);
    circle(coin.x, coin.y, coin.radius * 2);
    fill(255, 235, 120, illuminated ? 255 : 100);
    circle(coin.x - 3, coin.y - 3, coin.radius * 0.65);
  }
}

void drawTower() {
  float towerX = width * 0.5;
  float towerY = height * 0.67;

  if (towerImage != null) {
    imageMode(CENTER);
    image(towerImage, towerX, towerY - 85, 118, 170);
  } else {
    noStroke();
    fill(210);
    rectMode(CENTER);
    rect(towerX, towerY - 55, 95, 110, 28);
  }

  // Reference image/card supplied by the calibration tower.
  if (dist(pacmanX, pacmanY, towerX, towerY) < 115) drawReferenceCard();
}

void drawReferenceCard() {
  float cardX = width / 2;
  float cardY = 120;
  rectMode(CENTER);
  stroke(50);
  strokeWeight(2);
  fill(250, 245);
  rect(cardX, cardY, 260, 105, 12);

  noStroke();
  fill(40);
  textAlign(CENTER, CENTER);
  textSize(14);
  text("WHITE-BALANCE REFERENCE", cardX, cardY - 32);

  float startX = cardX - 75;
  fill(245); rect(startX, cardY + 8, 42, 42);
  fill(128); rect(startX + 50, cardY + 8, 42, 42);
  fill(35);  rect(startX + 100, cardY + 8, 42, 42);
  fill(230, 175, 140); rect(startX + 150, cardY + 8, 42, 42);
}

void drawInterface() {
  noStroke();
  fill(255, 238);
  rectMode(CORNER);
  rect(0, 0, width, 50);

  fill(25);
  textAlign(LEFT, CENTER);
  textSize(15);
  text("Score: " + score + " / " + coins.size(), 18, 25);
  text("RGB: " + currentR + ", " + currentG + ", " + currentB, 180, 25);
  text(connectionMessage, 410, 25);
  textAlign(RIGHT, CENTER);
  text("Move: Arrow keys / WASD", width - 18, 25);

  fill(currentR, currentG, currentB);
  stroke(30);
  circle(380, 25, 22);
}

void connectToArduino() {
  println("Available serial ports:");
  printArray(Serial.list());

  String selectedPort = null;
  for (String port : Serial.list()) {
    String lower = port.toLowerCase();
    if (lower.indexOf("usbmodem") >= 0 || lower.indexOf("usbserial") >= 0) {
      selectedPort = port;
      break;
    }
  }

  if (selectedPort == null) {
    connectionMessage = "Arduino not found — game-only mode";
    return;
  }

  try {
    arduino = new Serial(this, selectedPort, 9600);
    arduino.clear();
    connectionMessage = "Arduino: " + selectedPort;
  }
  catch (Exception error) {
    arduino = null;
    connectionMessage = "Serial connection failed";
    println(error.getMessage());
  }
}

void sendColorIfChanged() {
  if (arduino == null) return;
  if (currentR == lastSentR && currentG == lastSentG && currentB == lastSentB) return;
  if (millis() - lastColorSendTime < COLOR_SEND_INTERVAL_MS) return;

  arduino.write("C," + currentR + "," + currentG + "," + currentB + "\n");
  lastSentR = currentR;
  lastSentG = currentG;
  lastSentB = currentB;
  lastColorSendTime = millis();
}

void sendBlink() {
  if (arduino == null) return;
  arduino.write("B," + currentR + "," + currentG + "," + currentB + "\n");
}

void makeBlackPixelsTransparent(PImage imageToEdit) {
  imageToEdit.loadPixels();
  for (int i = 0; i < imageToEdit.pixels.length; i++) {
    color pixelColor = imageToEdit.pixels[i];
    float brightnessValue = brightness(pixelColor);

    if (brightnessValue < 18) {
      imageToEdit.pixels[i] = color(0, 0);
    } else if (brightnessValue < 55) {
      float alphaValue = map(brightnessValue, 18, 55, 0, 255);
      imageToEdit.pixels[i] = color(red(pixelColor), green(pixelColor),
                                         blue(pixelColor), alphaValue);
    }
  }
  imageToEdit.updatePixels();
}

void keyPressed() {
  if (keyCode == LEFT || key == 'a' || key == 'A') moveLeft = true;
  if (keyCode == RIGHT || key == 'd' || key == 'D') moveRight = true;
  if (keyCode == UP || key == 'w' || key == 'W') moveUp = true;
  if (keyCode == DOWN || key == 's' || key == 'S') moveDown = true;
}

void keyReleased() {
  if (keyCode == LEFT || key == 'a' || key == 'A') moveLeft = false;
  if (keyCode == RIGHT || key == 'd' || key == 'D') moveRight = false;
  if (keyCode == UP || key == 'w' || key == 'W') moveUp = false;
  if (keyCode == DOWN || key == 's' || key == 'S') moveDown = false;
}

class Coin {
  float x;
  float y;
  float radius = 10;
  boolean discovered = false;
  boolean collected = false;

  Coin(float x, float y) {
    this.x = x;
    this.y = y;
  }
}
