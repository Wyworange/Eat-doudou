// White-Balance Pac-Man RGB LED controller
// Arduino UNO R4 Minima
// Serial protocol:
//   C,red,green,blue  -> set the current color
//   B,red,green,blue  -> blink three times, then restore the current color

// External RGB LED wiring:
// Red leg   -> pin 9  through a 220-330 ohm resistor
// Green leg -> pin 10 through a 220-330 ohm resistor
// Blue leg  -> pin 11 through a 220-330 ohm resistor
// Common cathode -> GND; common anode -> power.
const byte redPin = 9;
const byte greenPin = 10;
const byte bluePin = 11;

int currentRed = 255;
int currentGreen = 255;
int currentBlue = 255;

const unsigned long BLINK_INTERVAL_MS = 120;
const byte BLINK_TOGGLE_LIMIT = 6;  // Six toggles = three flashes.

bool blinking = false;
bool blinkIsOn = true;
byte blinkToggleCount = 0;
unsigned long previousBlinkTime = 0;

char inputBuffer[40];
byte inputLength = 0;

void writeChannel(byte pin, int value) {
  value = constrain(value, 0, 255);
  // Common-cathode RGB LED: 0 = off, 255 = maximum brightness.
  analogWrite(pin, value);
}

void writeRGB(int red, int green, int blue) {
  writeChannel(redPin, red);
  writeChannel(greenPin, green);
  writeChannel(bluePin, blue);
}

void startBlink() {
  blinking = true;
  blinkIsOn = true;
  blinkToggleCount = 0;
  previousBlinkTime = millis();
  writeRGB(currentRed, currentGreen, currentBlue);
}

void updateBlink() {
  if (!blinking) return;
  if (millis() - previousBlinkTime < BLINK_INTERVAL_MS) return;

  previousBlinkTime = millis();
  blinkIsOn = !blinkIsOn;
  blinkToggleCount++;

  if (blinkToggleCount >= BLINK_TOGGLE_LIMIT) {
    blinking = false;
    writeRGB(currentRed, currentGreen, currentBlue);
    return;
  }

  if (blinkIsOn) {
    writeRGB(currentRed, currentGreen, currentBlue);
  } else {
    writeRGB(0, 0, 0);
  }
}

void processCommand(char *command) {
  char commandType;
  int red;
  int green;
  int blue;

  if (sscanf(command, "%c,%d,%d,%d", &commandType, &red, &green, &blue) != 4) {
    Serial.println("ERR,FORMAT");
    return;
  }

  if (commandType != 'C' && commandType != 'B') {
    Serial.println("ERR,COMMAND");
    return;
  }

  currentRed = constrain(red, 0, 255);
  currentGreen = constrain(green, 0, 255);
  currentBlue = constrain(blue, 0, 255);

  if (commandType == 'B') {
    startBlink();
  } else if (!blinking) {
    writeRGB(currentRed, currentGreen, currentBlue);
  }

  Serial.print("OK,");
  Serial.print(currentRed);
  Serial.print(',');
  Serial.print(currentGreen);
  Serial.print(',');
  Serial.println(currentBlue);
}

void readSerialCommands() {
  while (Serial.available() > 0) {
    char incoming = Serial.read();

    if (incoming == '\r') continue;

    if (incoming == '\n') {
      inputBuffer[inputLength] = '\0';
      if (inputLength > 0) processCommand(inputBuffer);
      inputLength = 0;
      continue;
    }

    if (inputLength < sizeof(inputBuffer) - 1) {
      inputBuffer[inputLength++] = incoming;
    } else {
      inputLength = 0;
      Serial.println("ERR,TOO_LONG");
    }
  }
}

void setup() {
  pinMode(redPin, OUTPUT);
  pinMode(greenPin, OUTPUT);
  pinMode(bluePin, OUTPUT);

  Serial.begin(9600);
  writeRGB(currentRed, currentGreen, currentBlue);
  // The website waits for this handshake before reporting synchronization.
  Serial.println("READY,WBPM1");
}

void loop() {
  readSerialCommands();
  updateBlink();
}
