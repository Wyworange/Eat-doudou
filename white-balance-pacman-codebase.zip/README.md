# 白平衡吃豆人（White-Balance Pac-Man）

## 1. 项目概念

这是一个受吃豆人启发的互动 RGB 灯光游戏。游戏地图同时是一张二维白平衡坐标图：玩家移动吃豆人时，会改变画面中的白平衡颜色，并通过 USB 串口同步控制 Arduino 上的实体 RGB LED。

核心体验：

1. 吃豆人的位置决定色温（Temperature）和色调（Tint）。
2. 白色遮罩在游戏规则中代表不可见的“黑暗”。
3. 吃豆人前方有手电筒式光锥，颜色与当前白平衡、实体 LED 一致。
4. 隐藏金币进入光锥后才会被发现。
5. 吃到金币时，画面和 RGB LED 闪烁，然后恢复当前白平衡颜色。
6. 吃豆人出生在一座塔中；塔展示参考图片，用于判断或校准白平衡。

## 2. 系统结构

```text
电脑游戏（推荐 Processing 或 p5.js）
├── 读取键盘/鼠标
├── 控制吃豆人移动和朝向
├── 将坐标转换为 Temperature 和 Tint
├── 将白平衡转换为 RGB
├── 绘制地图、白色遮罩、手电筒、塔和金币
├── 处理发现、碰撞、分数与关卡
└── 通过 USB 串口发送颜色及闪烁命令

Arduino
├── 接收串口命令
├── 使用 PWM 控制实体 RGB LED
└── 执行吃金币时的非阻塞闪烁
```

电脑画面、手电筒和实体 LED 必须共用同一组 `redVal`、`greenVal`、`blueVal`。

## 3. 白平衡坐标

```text
                         Tint：洋红
                              ↑
                              |
色温：冷/蓝  ←──────── 中性白 ────────→  色温：暖/黄
                              |
                              ↓
                          Tint：绿色
```

- 横坐标控制色温：左侧偏冷，右侧偏暖。
- 纵坐标控制 Tint：上方偏洋红，下方偏绿色。
- 地图中心对应中性白。

```java
float temperature = map(pacmanX, 0, mapWidth, -1, 1);
float tint = map(pacmanY, 0, mapHeight, -1, 1);
```

## 4. 简化的白平衡到 RGB 转换

以下算法适合视觉原型，并非严格的摄影测色算法：

```java
int[] whiteBalanceToRGB(float temperature, float tint) {
  float r = 255;
  float g = 255;
  float b = 255;

  // 暖色减少蓝色，冷色减少红色。
  if (temperature > 0) {
    b -= temperature * 180;
  } else {
    r -= -temperature * 180;
  }

  // 绿色方向减少红/蓝；洋红方向减少绿色。
  if (tint > 0) {
    r -= tint * 100;
    b -= tint * 100;
  } else {
    g -= -tint * 140;
  }

  return new int[] {
    constrain(round(r), 0, 255),
    constrain(round(g), 0, 255),
    constrain(round(b), 0, 255)
  };
}
```

以后若要准确模拟摄影白平衡，可改用 Kelvin、Tint 或 CIE xy 色度转换，并根据实际 RGB LED 校准。

## 5. PWM 与 0～255

经典 Arduino PWM 接口通常使用 8 位数值。`2^8 = 256` 种组合，因此数值范围为 `0～255`。

```cpp
analogWrite(pin, 0);    // 0% 占空比
analogWrite(pin, 127);  // 约 50% 占空比
analogWrite(pin, 255);  // 约 100% 占空比
```

LED 在电气层面仍然只是快速地开和关。PWM 改变一个周期内“打开”的时间比例，让人眼感受到不同平均亮度。

## 6. 画面与手电筒

先绘制场景，再覆盖白色遮罩。白色区域代表未知、不可见区域。吃豆人前方的光锥从遮罩中揭示地图与金币。

保存最后一次有效移动方向：

```java
PVector facing = new PVector(1, 0);
```

- 右：`(1, 0)`
- 左：`(-1, 0)`
- 上：`(0, -1)`
- 下：`(0, 1)`

光锥由吃豆人位置、朝向、长度和夹角决定。它使用当前白平衡 RGB，并带适当透明度。

## 7. 金币机制

```java
enum CoinState {
  HIDDEN,
  DISCOVERED,
  COLLECTED
}
```

- `HIDDEN`：未被光照，不绘制。
- `DISCOVERED`：进入过光锥，建议保持可见。
- `COLLECTED`：已经被吃掉，不再绘制。

每一帧先检查金币是否进入光锥，再检查吃豆人是否与金币碰撞：

```java
if (dist(pacmanX, pacmanY, coin.x, coin.y) < eatDistance) {
  coin.state = CoinState.COLLECTED;
  score++;
  sendBlink(currentR, currentG, currentB);
}
```

## 8. 出生塔与参考图片

出生塔是白平衡校准中心：

1. 吃豆人从塔中出生。
2. 塔展示参考图片，例如灰卡、白纸、人脸、蓝天或植物。
3. 玩家离开塔，通过移动改变白平衡。
4. 玩家根据参考图寻找合适的白平衡区域或完成任务。
5. 返回塔时可以恢复中性白：`temperature = 0`、`tint = 0`。

正视角塔素材：

```text
assets/tower-front-view.png
```

当前素材是白塔加黑色背景。游戏需要透明素材时，可以去除黑色背景并导出透明 PNG。

## 9. 串口通信协议

建议一行一条命令：

```text
C,255,120,40
```

`C` 表示正常颜色，后面依次为 R、G、B。

```text
B,255,120,40
```

`B` 表示使用该颜色闪烁，然后恢复当前颜色。

电脑端不必每一帧发送。建议只在颜色变化时发送，或限制为每秒 20～30 次。

## 10. Arduino 接线

```text
红色通道：PWM 引脚 9
绿色通道：PWM 引脚 10
蓝色通道：PWM 引脚 11
```

每个通道串联约 `220Ω～330Ω` 限流电阻。

- 共阴极 RGB LED：公共脚接 GND，通常 `255` 最亮。
- 共阳极 RGB LED：公共脚接电源，输出应使用 `255 - value`。

## 11. Arduino 参考代码

```cpp
const int redPin = 9;
const int greenPin = 10;
const int bluePin = 11;

int currentR = 255;
int currentG = 255;
int currentB = 255;

bool blinking = false;
bool blinkOn = true;
int blinkChanges = 0;
unsigned long lastBlinkTime = 0;
const unsigned long blinkInterval = 120;

void writeRGB(int r, int g, int b) {
  analogWrite(redPin, constrain(r, 0, 255));
  analogWrite(greenPin, constrain(g, 0, 255));
  analogWrite(bluePin, constrain(b, 0, 255));
}

void startBlink() {
  blinking = true;
  blinkOn = true;
  blinkChanges = 0;
  lastBlinkTime = millis();
  writeRGB(currentR, currentG, currentB);
}

void updateBlink() {
  if (!blinking || millis() - lastBlinkTime < blinkInterval) return;

  lastBlinkTime = millis();
  blinkOn = !blinkOn;
  blinkChanges++;

  if (blinkChanges >= 6) {
    blinking = false;
    writeRGB(currentR, currentG, currentB);
  } else if (blinkOn) {
    writeRGB(currentR, currentG, currentB);
  } else {
    writeRGB(0, 0, 0);
  }
}

void readCommand() {
  if (!Serial.available()) return;

  String line = Serial.readStringUntil('\n');
  line.trim();

  char type;
  int r, g, b;
  if (sscanf(line.c_str(), "%c,%d,%d,%d", &type, &r, &g, &b) != 4) return;

  currentR = constrain(r, 0, 255);
  currentG = constrain(g, 0, 255);
  currentB = constrain(b, 0, 255);

  if (type == 'B') {
    startBlink();
  } else if (type == 'C' && !blinking) {
    writeRGB(currentR, currentG, currentB);
  }
}

void setup() {
  pinMode(redPin, OUTPUT);
  pinMode(greenPin, OUTPUT);
  pinMode(bluePin, OUTPUT);
  Serial.begin(9600);
  Serial.setTimeout(20);
  writeRGB(currentR, currentG, currentB);
}

void loop() {
  readCommand();
  updateBlink();
}
```

闪烁使用 `millis()`，而不是连续长时间 `delay()`，因此闪烁期间仍能接收串口数据。

## 12. Processing 串口发送代码

```java
import processing.serial.*;

Serial arduino;
int lastR = -1;
int lastG = -1;
int lastB = -1;

void setup() {
  size(900, 600);
  printArray(Serial.list());
  arduino = new Serial(this, Serial.list()[0], 9600);
}

void sendColor(int r, int g, int b) {
  if (r == lastR && g == lastG && b == lastB) return;

  arduino.write("C," + r + "," + g + "," + b + "\n");
  lastR = r;
  lastG = g;
  lastB = b;
}

void sendBlink(int r, int g, int b) {
  arduino.write("B," + r + "," + g + "," + b + "\n");
}
```

`Serial.list()[0]` 不一定总是 Arduino，应查看端口列表后选择正确端口。电脑程序连接串口时要关闭 Arduino IDE 的 Serial Monitor，以免端口被占用。

## 13. 建议的程序模块

```text
src/
├── Game                     # 初始化和主循环
├── Pacman                   # 位置、速度、朝向和绘制
├── WhiteBalanceController   # 坐标到 Temperature/Tint/RGB
├── Flashlight               # 光锥绘制和范围判断
├── Coin                     # 金币状态和碰撞
├── Tower                    # 出生点和参考图片
├── SerialController         # Arduino 通信
└── GameState                # 分数、关卡和重置
```

## 14. 推荐开发顺序

1. 实现吃豆人移动、朝向和边界限制。
2. 将坐标转换成 Temperature、Tint 和 RGB，用画面颜色验证。
3. 连接 Arduino，使 RGB LED 与画面同步。
4. 加入白色遮罩和手电筒光锥。
5. 加入隐藏金币、发现状态和碰撞。
6. 加入画面及实体 LED 闪烁反馈。
7. 加入出生塔、参考图片和重置/校准。
8. 最后加入迷宫、分数、声音、关卡与美术优化。

## 15. 常见错误

- 一个 Arduino 文件只能有一个 `setup()` 和一个 `loop()`。
- 不要把自动渐变示例与串口控制示例完整粘在同一文件中。
- 不要把 `&#x20;`、`\*`、`\<` 等网页转义符粘进代码。
- 不要在代码行末尾留下多余的反斜杠 `\`。
- `redVal` 中的 `Val` 只是 `Value` 的缩写，不是关键字。
- 将所有 RGB 数值限制在 `0～255`。
- 手电筒、画面和实体 LED 必须使用同一次白平衡转换的结果。
- 如果亮度逻辑相反，检查 LED 是共阴极还是共阳极。

## 16. 第一版完成标准

- 吃豆人可以移动并保存正确朝向。
- 地图位置能够产生不同白平衡颜色。
- 手电筒与实体 RGB LED 颜色同步。
- 金币在光照范围内才能被发现。
- 吃到金币后画面或实体灯闪烁三次。
- 吃豆人从塔中出生，塔能够显示参考图片。
- 返回塔或地图中心时可以恢复中性白平衡。

## 17. 当前可运行原型

本项目已经包含两端代码：

```text
arduino/WhiteBalancePacmanLED/WhiteBalancePacmanLED.ino
processing/WhiteBalancePacman/WhiteBalancePacman.pde
processing/WhiteBalancePacman/data/tower-front-view.png
```

运行顺序：

1. 在 Arduino IDE 中打开 `WhiteBalancePacmanLED.ino`。
2. 开发板选择 Arduino UNO R4 Minima，并选择正确 USB 端口。
3. 上传代码；需要单独测试时，可在 9600 波特率的 Serial Monitor 中发送 `C,255,0,0`。
4. 测试完成后关闭 Serial Monitor，避免它占用串口。
5. 安装并打开 Processing 4，在 Processing 中打开 `WhiteBalancePacman.pde`。
6. 点击运行。程序会优先寻找名称包含 `usbmodem` 或 `usbserial` 的端口。
7. 使用方向键或 WASD 移动吃豆人。

界面顶部会显示 Arduino 连接状态。若显示 `game-only mode`，游戏仍可运行，但实体 RGB LED 不会响应；此时检查 USB 数据线、Arduino 程序是否已上传，以及 Serial Monitor 是否已关闭。
